﻿// SDL_Test.cpp: Definiert den Einstiegspunkt für die Anwendung.
//

#include "Project_SDL1.h"

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <numeric>
#include <random>
#include <string>

bool interRect(int ax, int ay, int bx, int by) {
    if (ax >= bx && ax <= bx + 50 && ay >= by && ay <= by + 50) {
        return true;
    }
    if (ax + 50 >= bx && ax + 50 <= bx + 50 && ay >= by && ay <= by + 50) {
        return true;
    }
    if (ax >= bx && ax <= bx + 50 && ay+50 >= by && ay+50 <= by + 50) {
        return true;
    }
    if (ax + 50 >= bx && ax + 50 <= bx + 50 && ay+50 >= by && ay+50 <= by + 50) {
        return true;
    }

    return false;
}

void ground::moveAll() {

    int bergX = 0;
    int bergY = 0;

    for (int i = 0; i < animals_.size(); i++) {
        if (animals_[i]->isPredator() == true) {
            double dogDistance = 300;
            int dog = 0;
            double preyDistance = 10000000;
            int prey = 0;
            double distX = 0;
            double distY = 0;
            double dist = 0;

            for (int j = 0; j < animals_.size(); j++) {
                distX = sqrt((animals_[j]->X() - animals_[i]->X()) * (animals_[j]->X() - animals_[i]->X()));
                distY = sqrt((animals_[j]->Y() - animals_[i]->Y()) * (animals_[j]->Y() - animals_[i]->Y()));
                dist = distX + distY;

                if (animals_[j]->isDog() == true) {
                    if (dist < dogDistance) {
                        dogDistance = dist;
                        dog = j;
                    }
                }

                if (animals_[j]->isPrey() == true) {
                    std::cout << animals_[i]->X() << " " << animals_[j]->X() << "  " << animals_[i]->Y() << " " << animals_[j]->Y() << "\n";
                    if (interRect(animals_[i]->X(),animals_[i]->Y(), animals_[j]->X(),animals_[j]->Y())) {
                        std::cout << "manger\n";
                        std::vector < std:: unique_ptr<animal >> ::iterator it;
                        it = animals_.begin()+j;
                        animals_.erase(it);
                    }
                    else if (dist < preyDistance) {
                        preyDistance = dist;
                        prey = j;
                    }
                }
            }
            if (dogDistance < 200) {
                distX = animals_[dog]->X() - animals_[i]->X();
                distY = animals_[dog]->Y() - animals_[i]->Y();
                if (distX == 0) {
                    distX = 1;
                }
                if (distY == 0) {
                    distY = 1;
                }
                animals_[i]->setDirx(-(distX / sqrt(distX * distX)));
                animals_[i]->setDiry(-(distY / sqrt(distY * distY)));
            }
            else if (dogDistance >= 300) {
                distX = animals_[prey]->X() - animals_[i]->X();
                distY = animals_[prey]->Y() - animals_[i]->Y();
                if (distX == 0) {
                    distX = 1;
                }
                if (distY == 0) {
                    distY = 1;
                }
                animals_[i]->setDirx((distX / sqrt(distX * distX)));
                animals_[i]->setDiry((distY / sqrt(distY * distY)));
            }
        }

        else if (animals_[i]->isPrey() == true) {
            if (animals_[i]->repos() > 0) {
                animals_[i]->setRepos(animals_[i]->repos() - 1);
            }

            double predatorDistance = 10000000;
            int predator = 0;
            double distX = 0;
            double distY = 0;
            double dist = 0;

            for (int j = 0; j < animals_.size(); j++) {
                if (animals_[j]->isPrey()) {
                    if (interRect(animals_[i]->X(), animals_[i]->Y(), animals_[j]->X(), animals_[j]->Y())) {
                        if ((animals_[j]->isFemale() && animals_[i]->isFemale() == false && animals_[j]->repos() == 0) || (animals_[i]->isFemale() && animals_[j]->isFemale() == false && animals_[i]->repos() == 0)) {
                            animals_[i]->setRepos(1500);
                            animals_[j]->setRepos(1500);
                            std::unique_ptr<animal> s(new sheep(window_surface_ptr_));
                            animals_.push_back(std::move(s));
                        }
                    }
                }
                distX = sqrt((animals_[j]->X() - animals_[i]->X()) * (animals_[j]->X() - animals_[i]->X()));
                distY = sqrt((animals_[j]->Y() - animals_[i]->Y()) * (animals_[j]->Y() - animals_[i]->Y()));
                dist = distX + distY;

                if (animals_[j]->isPredator() == true) {
                    if (dist < predatorDistance) {
                        predatorDistance = dist;
                        predator = j;
                    }
                }
            }
            if (predatorDistance < 300) {
                distX = animals_[predator]->X() - animals_[i]->X();
                distY = animals_[predator]->Y() - animals_[i]->Y();
                if (distX == 0) {
                    distX = 1;
                }
                if (distY == 0) {
                    distY = 1;
                }
                animals_[i]->setDirx(-(distX / sqrt(distX * distX)) * 3);
                animals_[i]->setDiry(-(distY / sqrt(distY * distY)) * 3);
            }
            if (predatorDistance > 400) {
                animals_[i]->setDirx(animals_[i]->getDirx() % 2);
                animals_[i]->setDiry(animals_[i]->getDiry() % 2);
            }
        }

        if (animals_[i]->isBerg()) {

            bergX = animals_[i]->X();
            bergY = animals_[i]->Y();

            const Uint8* key = SDL_GetKeyboardState(nullptr);
            animals_[i]->setDirx(0);
            animals_[i]->setDiry(0);
            if (key[SDL_SCANCODE_UP]) {
                animals_[i]->setDiry(-1);
            }
            if (key[SDL_SCANCODE_DOWN]) {
                animals_[i]->setDiry(1);
            }
            if (key[SDL_SCANCODE_RIGHT]) {
                animals_[i]->setDirx(1);
            }
            if (key[SDL_SCANCODE_LEFT]) {
                animals_[i]->setDirx(-1);
            }
        }

        if (animals_[i]->isDog()) {
            animals_[i]->setBergX(bergX);
            animals_[i]->setBergY(bergY);
        }

        animals_[i]->move();
    }
}
void ground::drawAll() {
    SDL_FillRect(window_surface_ptr_, NULL, SDL_MapRGB(window_surface_ptr_->format, 0, 200, 0));
    for (int i = 0; i < animals_.size(); i++) {
        animals_[i]->draw();
    }
}


void init() {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_TIMER | SDL_INIT_VIDEO) < 0)
        throw std::runtime_error("init():" + std::string(SDL_GetError()));

    // Initialize PNG loading
    int imgFlags = IMG_INIT_PNG;
    if (!(IMG_Init(imgFlags) & imgFlags))
        throw std::runtime_error("init(): SDL_image could not initialize! "
            "SDL_image Error: " +
            std::string(IMG_GetError()));
}

namespace {
    // Defining a namespace without a name -> Anonymous workspace
    // Its purpose is to indicate to the compiler that everything
    // inside of it is UNIQUELY used within this source file.

    SDL_Surface* load_surface_for(const std::string& path,
        SDL_Surface* window_surface_ptr) {

        // Helper function to load a png for a specific surface
        // See SDL_ConvertSurface
    }
}

application::application(unsigned n_sheep, unsigned n_wolf) : g(ground(window_surface_ptr_, n_sheep, n_wolf)) {
    window_ptr_ = SDL_CreateWindow("SDL2 Window",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        frame_width, frame_height,
        0);
    window_surface_ptr_ = SDL_GetWindowSurface(window_ptr_);
    g.setWindow_surface_ptr_(window_surface_ptr_);

    for (int i = 0; i < g.getN(); i++) {
        g.setW_(window_surface_ptr_, i);
    }
}

application::~application() {
    SDL_DestroyWindow(window_ptr_);
}

int application::loop(unsigned period) {
    auto start = SDL_GetTicks();

    SDL_Event e;
    bool quit = false;
    while (!quit && (SDL_GetTicks() - start < period)) {
        g.update(window_ptr_);
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                quit = true;
                break;
            }
        }
    }
    return 0;
}

ground::ground(SDL_Surface* window_surface_ptr, int n_sheep, int n_wolf) {
    window_surface_ptr_ = window_surface_ptr;
    std::unique_ptr<animal> berg(new berger(window_surface_ptr));
    animals_.push_back(std::move(berg));
    for (int i = 0; i < n_sheep; i++) {
        std::unique_ptr<animal> s(new sheep(window_surface_ptr_));
        animals_.push_back(std::move(s));
    }
    for (int i = 0; i < n_wolf; i++) {
        std::unique_ptr<animal> s(new wolf(window_surface_ptr));
        animals_.push_back(std::move(s));
    }
    std::unique_ptr<animal> s(new dog(window_surface_ptr));
    animals_.push_back(std::move(s));

};
// todo: Ctor


//auto it = myvector.begin(); it != myvector.end();++it
//auto&& a : animals_
void ground::update(SDL_Window* window_ptr) {

    moveAll();
    drawAll();
    SDL_UpdateWindowSurface(window_ptr);
}

